#!/usr/bin/env python

from rottentomatoes import RT

__all__ = [RT]
