#!/usr/bin/env python

"""
Rotten Tomatoes API:  http://developer.rottentomatoes.com/

Store your API key in this file -- that way the `RT` class can be initialized
without having to pass it in as an argument.
"""

API_KEY = ''
