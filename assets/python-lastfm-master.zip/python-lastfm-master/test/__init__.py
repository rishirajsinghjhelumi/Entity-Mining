from lastfm import Api
Api.FETCH_INTERVAL = 0

import test_album
import test_tag
import test_event
import test_artist
import test_geo
import test_group
import test_playlist
import test_track
import test_user